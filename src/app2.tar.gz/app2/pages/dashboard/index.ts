export * from './dashboard.component';
export * from './dashboard.module';
